﻿using AdminPanel_CoreAPI.Models;
using AdminPanel_CoreAPI.Models.DTO;
using AdminPanel_CoreAPI.Repository;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AdminPanel_CoreAPI.Services
{
    [ApiController]
    [Route("[controller]")]
    public class CustomerService : Controller
    {
        readonly ICustomerRepository _ICustomerRepository;
        public CustomerService(ICustomerRepository CustomerRepository)
        {
            _ICustomerRepository = CustomerRepository;
        }

        [HttpPost("CustomerService/AddProduct")]
        public ActionResult AddProduct(ProductDTO ObjProduct)
        {
            return Ok(_ICustomerRepository.AddProduct(ObjProduct));
        }

        [HttpGet("CustomerService/GetProductList")]
        public ActionResult<List<ProductDTO>> GetProductList()
        {
            return Ok(_ICustomerRepository.GetProductList());
        }

        [HttpPost("CustomerService/PlaceOrder")]
        public ActionResult PlaceOrder(PlaceOrder ObjPlaceOrder)
        {
            return Ok(_ICustomerRepository.PlaceOrder(ObjPlaceOrder));
        }

        [HttpGet("CustomerService/GetAllOrders")]
        public ActionResult<List<OrderListDTO>> GetAllOrders( [FromQuery] string OrderId)
        {
            return Ok(_ICustomerRepository.GetAllOrder( Convert.ToInt32(OrderId)));
        }

        [HttpGet("CustomerService/DeleteOrder")]
        public ActionResult DeleteOrder([FromQuery] int OrderId)
        {
            return Ok(_ICustomerRepository.DeleteOrder(OrderId));
        }

    }
}
