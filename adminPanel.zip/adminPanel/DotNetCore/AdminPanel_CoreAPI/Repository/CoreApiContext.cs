﻿using AdminPanel_CoreAPI.Models;
using AdminPanel_CoreAPI.Models.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AdminPanel_CoreAPI.Repository
{
    public class CoreApiContext: DbContext
    {
        protected override void OnConfiguring
       (DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseInMemoryDatabase(databaseName: "CustomerDB");
        }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<ShippingAddress> ShippingAddress { get; set; }

        public DbSet<Product> Products { get; set; }
        public DbSet<CustomerOrder> CustomerOrders { get; set; }
    }
}
