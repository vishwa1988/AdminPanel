﻿using AdminPanel_CoreAPI.Models;
using AdminPanel_CoreAPI.Models.DTO;
using AdminPanel_CoreAPI.Models.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AdminPanel_CoreAPI.Repository
{
    public class CustomerRepository : ICustomerRepository
    {
        public CustomerRepository()
        {
            using (var context = new CoreApiContext())
            {
                if(!context.Products.Any())
                {
                    List<Product> prdList = new List<Product>();
                    prdList.Add(new Product
                    {
                        ProductName = "Product1",
                        UnitPrice = 10,
                        IsActive = true,
                        CreatedOn = DateTime.Now,
                        UpdatedOn = DateTime.Now

                    });
                    prdList.Add(new Product
                    {
                        ProductName = "Product2",
                        UnitPrice = 20,
                        IsActive = true,
                        CreatedOn = DateTime.Now,
                        UpdatedOn = DateTime.Now

                    });
                    context.AddRange(prdList);
                    context.SaveChanges();

                }
                
            }
        }
        public string AddProduct(ProductDTO Pdto)
        {
            using (var context = new CoreApiContext())
            {
                var Products =
                new Product
                {
                    ProductName = Pdto.ProductName,
                    UnitPrice = Pdto.UnitPrice,
                    IsActive = true,
                    CreatedOn = DateTime.Now,
                    UpdatedOn = DateTime.Now

                };
                context.Add(Products);
                context.SaveChanges();
            }

            return "1";
        }

        public List<ProductDTO> GetProductList()
        {
            var ProductDTO = new List<ProductDTO>();
            using (var context = new CoreApiContext())
            {
                var Products = context.Products.Where(s => s.IsActive == true).Select(s => new ProductDTO
                {
                    ProductId = s.ProductId,
                    ProductName = s.ProductName,
                    UnitPrice = s.UnitPrice
                }).ToList();

                ProductDTO = Products;
            }

            return ProductDTO;
        }

        public string PlaceOrder(PlaceOrder ObjPlaceOrder)
        {
            using (var context = new CoreApiContext())
            {
                var Customers =
                new Customer
                {
                    FirstName = ObjPlaceOrder.FirstName,
                    LastName = ObjPlaceOrder.LastName,
                    Email = ObjPlaceOrder.Email,
                    Address = new ShippingAddress()
                    {
                        Street = ObjPlaceOrder.Address.Street,
                        City = ObjPlaceOrder.Address.City,
                        Zip = ObjPlaceOrder.Address.Zip

                    }

                };
                context.Add(Customers);
                context.SaveChanges();

                var CustomerOrder = new CustomerOrder();
                CustomerOrder.ProductId = ObjPlaceOrder.ProductId;
                CustomerOrder.TotalCost = ObjPlaceOrder.TotalCost;
                CustomerOrder.OrderPlacedOn = DateTime.Now;
                CustomerOrder.CustomerId = Customers.CustomerId;
                CustomerOrder.Quantity = ObjPlaceOrder.Quantity;
                context.Add(CustomerOrder);
                context.SaveChanges();

            }

            return "1";
        }
        public List<CustomerDTO> Customer()
        {
            var CustonerList = new List<CustomerDTO>();
            var CustonerDTO = new CustomerDTO();
            
            using (var context = new CoreApiContext())
            {
                IQueryable<Customer> List;
                List = context.Customers
                    .Include(a => a.Address);

                foreach(var item in List)
                {
                    CustonerDTO.Address = new AddressDTO();
                    CustonerDTO.FirstName = item.FirstName;
                    CustonerDTO.LastName = item.LastName;
                    CustonerDTO.Email = item.LastName;
                    CustonerDTO.Address.City = item.Address.City;
                    CustonerDTO.Address.Street = item.Address.Street;
                    CustonerDTO.Address.Zip = item.Address.Zip;
                    CustonerList.Add(CustonerDTO);

                }


            }
            return CustonerList;

        }

        public List<OrderListDTO> GetAllOrder(int OrderId=0)
        {
            var CustonerList = new List<CustomerDTO>();
            var CustomerOrderList = new List<OrderListDTO>();
            using (var context = new CoreApiContext())
            {
                IQueryable<Customer> List;
                List = context.Customers
                    .Include(a => a.Address);
                var CustomerOrders = context.CustomerOrders.ToList();
                
                foreach (var item in List)
                {
                    var CustonerDTO = new CustomerDTO();
                    CustonerDTO.Address = new AddressDTO();
                    CustonerDTO.FirstName = item.FirstName;
                    CustonerDTO.LastName = item.LastName;
                    CustonerDTO.Email = item.Email;
                    CustonerDTO.Address.City = item.Address.City;
                    CustonerDTO.Address.Street = item.Address.Street;
                    CustonerDTO.Address.Zip = item.Address.Zip;
                    CustonerDTO.CustomerId = item.CustomerId;
                    CustonerList.Add(CustonerDTO);

                }

                var OrderList = from s in CustonerList
                                join st in CustomerOrders
                                on s.CustomerId equals st.CustomerId
                                join p in context.Products on st.ProductId equals p.ProductId
                                select new OrderListDTO
                                { Orderid = st.CustomerOrderId,
                                    FirstName = s.FirstName,
                                    LastName = s.LastName,
                                    Email = s.Email,
                                    ProductName = p.ProductName,
                                    UnitPrice = p.UnitPrice,
                                    Quantity = st.Quantity,
                                    TotalCost = st.TotalCost,
                                    OrderPlacedOn = Convert.ToDateTime( st.OrderPlacedOn.ToShortDateString())
                                };
                CustomerOrderList = OrderList.OrderByDescending(s=>s.OrderPlacedOn).ToList();

                if(OrderId>0)
                {
                    CustomerOrderList = CustomerOrderList.Where(s => s.Orderid == OrderId).ToList();
                }


            }
            return CustomerOrderList;
        }
        public string DeleteOrder(int OrderId)
        {
            using (var context = new CoreApiContext())
            {
                var Products = context.CustomerOrders.Where(s => s.CustomerOrderId == OrderId).FirstOrDefault();
                context.Remove(Products);
                context.SaveChanges();
            }
            return "1";
        }
    }

    
}
