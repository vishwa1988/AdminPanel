﻿using AdminPanel_CoreAPI.Models;
using AdminPanel_CoreAPI.Models.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AdminPanel_CoreAPI.Repository
{
    public interface ICustomerRepository
    {

        public string AddProduct(ProductDTO PrdDto);
        public List<ProductDTO> GetProductList();
        public List<CustomerDTO> Customer();
        public string PlaceOrder(PlaceOrder ObjPlaceOrder);

        public List<OrderListDTO> GetAllOrder(int OrderId);
        public string DeleteOrder(int OrderId);

    }
}
