import { HttpClient, HttpParams, HttpHeaders } from "@angular/common/http";
import { Inject, Injectable } from "@angular/core";
import { map, tap } from "rxjs/operators";

@Injectable({
  providedIn: "root",
})
export class orderService {

  BaseURL: String = "http://localhost:1220";
  constructor(
    private http: HttpClient,
  ) { }

  public getProduct() {
    return this.http.get(
      `${this.BaseURL}/CustomerService/CustomerService/GetProductList`
    );
  }

  public placeOrder(order: any) {
    return this.http.post<any>(`${this.BaseURL}/CustomerService/CustomerService/PlaceOrder`, order);
  }

  public getOrders(OrderId:any=0) {
    return this.http.get(
      `${this.BaseURL}/CustomerService/CustomerService/GetAllOrders?OrderId=`+OrderId
    );
  }

  public deleteOrder(OrderId: any = 0) {
    return this.http.get(
      `${this.BaseURL}/CustomerService/CustomerService/DeleteOrder?OrderId=` + OrderId
    );
  }
  
}
