import { Component, OnInit } from '@angular/core';
import { orderService } from 'src/services/orderService';
@Component({
  selector: 'app-searchorder',
  templateUrl: './searchorder.component.html',
  styleUrls: ['./searchorder.component.css']
})
export class SearchorderComponent implements OnInit {
  orderList: any[] = [];
  OrderId:string="" ;
  constructor(private orderService: orderService) { }

  ngOnInit(): void {
    this.orderService.getOrders(this.OrderId).subscribe((res: any) => {
      this.orderList = res;
    })
  }

  searchOrder() {
    if (this.OrderId=="")
    this.orderService.getOrders(this.OrderId).subscribe((res: any) => {
      this.orderList = res;
    })

  }

  deleteOrder(OrderId:number) {
      this.orderService.deleteOrder(OrderId).subscribe((res: any) => {
        if (res == "1") {

          this.searchOrder();
        }
      })

  }
}
