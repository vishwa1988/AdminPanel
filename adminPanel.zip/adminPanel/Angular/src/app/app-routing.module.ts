import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { SearchorderComponent } from 'src/searchorder/searchorder.component';
import { HomeComponent } from './home/home.component';

const routes: Routes = [
  
  {
    path: 'SearchOrder',
    component: SearchorderComponent,
  },
  {
    path: 'Order',
    component: AppComponent,
  },
  { path: '**', redirectTo: 'Order' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
