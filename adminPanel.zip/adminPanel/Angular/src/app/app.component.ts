import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {orderService } from 'src/services/orderService';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit  {

  productList :any[]=[];
  orderModel: any = {};
  unitPrice: number = 0;
  totalCost: number = 0;
  constructor(private orderService: orderService, private readonly router: Router) { }

  ngOnInit() {
    this.orderService.getProduct().subscribe((res:any) => {
      this.productList = res;
    })
  }
  placeorder(data:any) {
   this.orderModel= {
     "firstName": data.firstname,
     "lastName": data.LastName,
     "email": data.Email,
     "productId": data.Product,
     "quantity": data.Quantity,
      "totalCost":this.totalCost,
      "address": {
        "street": data.Street,
        "city": data.City,
        "zip": data.Zip
      }
    }
    this.orderService.placeOrder(this.orderModel).subscribe((res: any) => {
      if (res == '1') {

        this.router.navigate([
          `/SearchOrder`,
        ]);
      }
    })
  }

  checkUnitPrice(item: any) {
   let itemSelected = this.productList.find(x => x.productId == item.value)
    this.unitPrice = itemSelected.unitPrice
  }

  calculateCost(quantity: any) {

    this.totalCost = quantity.value * this.unitPrice;

  }
 
}


